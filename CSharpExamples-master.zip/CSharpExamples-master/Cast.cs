using System.IO;
using System;


class Program
{
    static void Main(string[] args)
    {
       double value_double=19.03; 
       int value_int;
       
       value_int=(int)value_double; //double dan int e cast işlemi yapıldı.
       Console.WriteLine(value_int); //19
       
    }
}
