using System;
class Program
{
   static void Main(string[] args)
   {
      int a = 1903;
      int b = 1967;
      
      if (a == b)
      {
         Console.WriteLine("A eşittir B");
      }
     
      else if (a < b)
      {
         Console.WriteLine("A B den küçüktür.");
      }
      
      
     else if (a > b)
      {
         Console.WriteLine("A B den büyüktür.");
      }
      
      
     
   }
}
