using System;
namespace VariableDefinition 
{
   class Program 
   {
      static void Main(string[] args) 
      {
         short a;
         int b ;
         double c;

         a = 10; // 0.eleman
         b = 20; // 1.eleman
         c = a + b; //2.eleman 
         Console.WriteLine("a = {0}, b = {1}, c = {2}", a, b, c);
     
      }
   }
}
