using System.IO;
using System;


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Size of int: {0}", sizeof(int)); //size of int : 4
        Console.ReadLine();
        Console.WriteLine("Size of float: {0}", sizeof(float)); //size of float : 4
        Console.ReadLine();
        Console.WriteLine("Size of double: {0}", sizeof(double)); //size of double : 8
        Console.ReadLine();
        Console.WriteLine("Size of char: {0}", sizeof(char)); //size of char : 2
        Console.ReadLine();
       
    }
}
