# C# Examples

Hello Friends, we started to speak C# Language and I wanted to share with you examples in their collections. We will continue to share with you as he tries to make the basic tables of C Sharp and produces more examples.

C# is a general-purpose high-level programming language supporting multiple paradigms. C# encompasses static typing, strong typing, lexically scoped, imperative, declarative, functional, generic, object-oriented, and component-oriented programming disciplines.

